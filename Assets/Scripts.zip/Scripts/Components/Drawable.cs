using System;
using UnityEngine;

public struct DrawableMeshBundle
{
    public Guid MeshHandle;
    public Guid ShaderHandle;
    public Transform Transform;

    public DrawableMeshBundle(Guid meshHandle, Guid shaderHandle, Transform transform)
    {
        MeshHandle = meshHandle;
        ShaderHandle = shaderHandle;
        Transform = transform;
    }
}

public struct GLDrawMode
{
    public PrimitiveType Mode;

    public GLDrawMode(PrimitiveType mode)
    {
        Mode = mode;
    }
}

public class TransparencyPass { }
