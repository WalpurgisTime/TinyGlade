using System;

/*
using OpenTK.Mathematics;

// Mark the cube that follows the mouse raycast intersection
public class FollowMouse { }

// Stores the result of a cursor raycast
public struct CursorRaycast
{
    public Vector3 Position;

    public CursorRaycast(Vector3 position)
    {
        Position = position;
    }
}

*/

// Used for display testing
public class DisplayTestMask { }

// Represents an indirect draw component
public class IndirectDraw { }

// Represents a road-related component
public class RoadComponent { }
