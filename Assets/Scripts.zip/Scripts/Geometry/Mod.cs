namespace Geometry
{
    public static class Modules
    {
        public static void LoadAll()
        {
            // Charger ou initialiser les modules si n�cessaire
        }
    }
}
