using UnityEngine;
using UnityEngine.EventSystems;

public class DrawWall : MonoBehaviour
{
    public BrushMode _mode;
    public WallManager wallManager;
    public MouseRaycast mouseRaycast;

    private const float CONTINUE_CURVE_DIST_THRESHOLD = 0.2f;
    private bool isDrawing = false;
    private int activeCurveIndex = -1;

    void Update()
    {
        if (_mode != BrushMode.Wall) return;

        Vector3 cursorPosition = mouseRaycast.cursorWorldPosition;
        cursorPosition.y = 0.0f;

        if (Input.GetMouseButtonDown(0)) // Commencer un mur
        {
            TryStartNewCurve(cursorPosition);
        }
        else if (Input.GetMouseButton(0)) // Continuer le mur existant
        {
            ContinueActiveCurve(cursorPosition);
        }
    }

    void TryStartNewCurve(Vector3 cursor_ws)
    {
        isDrawing = true;

        foreach (var wallEntry in wallManager.walls)
        {
            Wall wall = wallEntry.Value;
            if (wall.curve != null && wall.curve.IsNear(cursor_ws, CONTINUE_CURVE_DIST_THRESHOLD))
            {
                activeCurveIndex = wallEntry.Key;
                return;
            }
        }

        activeCurveIndex = wallManager.NewWall(new Curve());
    }

    void ContinueActiveCurve(Vector3 cursor_ws)
    {
        if (!isDrawing || activeCurveIndex == -1) return;

        var temp_wall = wallManager.GetWall(activeCurveIndex);
        if (temp_wall != null && temp_wall.curve != null && temp_wall.curve.CanAddPoint(cursor_ws))
        {
            temp_wall.curve.AddPoint(cursor_ws);
            temp_wall.curve.SmoothAndResample();
        }
    }
}