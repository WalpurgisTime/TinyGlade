using System.Collections.Generic;
using UnityEngine;

public class ConstructWallNShadows : MonoBehaviour
{
    public BrushMode currentMode;

    public WallManager wallManager;
    public MeshLibrary assetMeshLibrary;
    public ShaderLibrary assetShaderLibrary;

    // Simule l'�quivalent de EventReader<CurveChangedEvent>
    private List<int> curveChangedBuffer = new List<int>();

    void OnEnable()
    {
        GameEvents.OnCurveChanged.AddListener(OnCurveChangedEvent);
    }

    void OnDisable()
    {
        GameEvents.OnCurveChanged.RemoveListener(OnCurveChangedEvent);
    }

    void OnCurveChangedEvent(int curveIndex)
    {
        curveChangedBuffer.Add(curveIndex);
    }

    public void walls_update()
    {
        // Check mode
        if (currentMode != BrushMode.Wall && currentMode != BrushMode.EraserAll)
            return;

        foreach (int curveIndex in curveChangedBuffer)
        {
            Wall changedWall = wallManager.GetWall(curveIndex);
            if (changedWall == null)
            {
                Debug.LogError($"Wall construction failed: couldn't get Wall index {curveIndex}");
                continue;
            }

            if (changedWall.curve.points.Count < 2)
                continue;

            // === CONSTRUCTION DU MUR ===
            List<Brick> bricks = WallConstructor.FromCurve(changedWall.curve);
            if (bricks.Count == 0)
            {
                Debug.LogWarning("WallConstructor returned empty wall");
                continue;
            }

            if (changedWall.wallEntity != null)
            {
                InstancedWall wallComponent = changedWall.wallEntity.GetComponent<InstancedWall>();
                wallComponent.UpdateWall(changedWall.curve.length, bricks);
            }
            else
            {
                Debug.Log("creating wall..");
                changedWall.wallEntity = CreateWall(
                    changedWall.curve.length,
                    bricks
                );
            }

            // === SHADOW DECAL ===
            if (changedWall.shadowEntity != null)
            {
                var meshFilter = changedWall.shadowEntity.GetComponent<MeshFilter>();
                Mesh mesh = meshFilter.sharedMesh;
                ShadowDecal.Update(changedWall.curve, mesh);
            }
            else
            {
                changedWall.shadowEntity = ShadowDecal.New(
                    changedWall.curve,
                    assetMeshLibrary,
                    assetShaderLibrary
                );
            }
        }

        Debug.Log("Wall construction done");

        curveChangedBuffer.Clear();
    }

    private GameObject CreateWall(float curveLength, List<Brick> bricks)
    {
        GameObject wallGO = new GameObject("InstancedWall");
        wallGO.AddComponent<MeshFilter>();
        wallGO.AddComponent<MeshRenderer>();

        var wallComponent = wallGO.AddComponent<InstancedWall>();
        wallComponent.Init(curveLength, bricks);

        Mesh mesh = assetMeshLibrary.GetMeshByName("brick");
        Shader shader = assetShaderLibrary.GetShaderByName("instanced_wall_shader");

        wallGO.GetComponent<MeshFilter>().mesh = mesh;
        wallGO.GetComponent<MeshRenderer>().material = new Material(shader);

        return wallGO;
    }
}

/*
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;


public class CosntructWallNShadows : MonoBehaviour
{
    public BrushMode _mode;
    public WallManager wallManager;
    public MeshLibrary assetsMesh;
    public ShaderLibrary assetsShader;

    void OnEnable()
    {
        GameEvents.OnCurveChanged.AddListener(OnCurveChanged);
    }

    void OnDisable()
    {
        GameEvents.OnCurveChanged.RemoveListener(OnCurveChanged);
    }

    private void OnCurveChanged(int curveIndex)
    {
        if (_mode != BrushMode.Wall && _mode != BrushMode.EraserAll) return;

        Wall changedWall = wallManager.GetWall(curveIndex);
        if (changedWall == null || changedWall.curve.points.Count < 2) return;

        UpdateWall(changedWall);
        UpdateShadow(changedWall);
    }

    private void UpdateWall(Wall changedWall)
    {
        List<Brick> bricks = WallConstructor.FromCurve(changedWall.curve);

        if (bricks.Count == 0)
        {
            Debug.LogWarning("WallConstructor returned empty wall");
            return;
        }

        if (changedWall.wallEntity != null)
        {
            InstancedWall wallComponent = changedWall.wallEntity.GetComponent<InstancedWall>();
            wallComponent.Update(changedWall.curve.length, bricks);
        }
        else
        {
            Debug.Log("Creating wall...");
            changedWall.wallEntity = CreateWall(changedWall.curve.length, bricks);
        }
    }

    private void UpdateShadow(Wall changedWall)
    {
        if (changedWall.shadowEntity != null)
        {
            MeshFilter meshFilter = changedWall.shadowEntity.GetComponent<MeshFilter>();
            if (meshFilter != null)
            {
                ShadowDecal.UpdateShadowMesh(changedWall.curve, meshFilter.mesh);
            }
        }
        else
        {
            GameObject shadowObject = new GameObject("ShadowDecal");
            shadowObject.AddComponent<MeshFilter>().mesh = ShadowDecal.CreateShadowMesh(changedWall.curve);
            changedWall.shadowEntity = shadowObject;
        }
    }

    private GameObject CreateWall(float curveLength, List<Brick> bricks)
    {
        InstancedWall wallComponent = new InstancedWall(curveLength, bricks);
        GameObject wallObject = new GameObject("InstancedWall");
        wallObject.AddComponent<MeshFilter>().mesh = assetsMesh.GetMeshByName("brick");
        wallObject.AddComponent<MeshRenderer>().material = assetsShader.GetMaterial("instanced_wall_shader");
        wallObject.AddComponent<InstancedWallData>().Initialize(wallComponent);

        return wallObject;
    }


}

*/